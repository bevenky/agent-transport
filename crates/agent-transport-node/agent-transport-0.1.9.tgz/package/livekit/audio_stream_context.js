/**
 * AudioStreamJobContext — equivalent of LiveKit's JobContext for Plivo audio streaming.
 *
 * Matches the SIP JobContext pattern:
 *   server.audioStreamSession(async (ctx) => {
 *     const session = new voice.AgentSession({ ... });
 *     ctx.session = session;
 *     await session.start({ agent, room: ctx.room });
 *   });
 */
import { mkdirSync, writeSync } from 'node:fs';
import { SipAudioInput } from './sip_audio_input.js';
import { SipAudioOutput } from './sip_audio_output.js';
import { TransportRoom } from './livekit_adapters.js';
import { JobProcess } from './agent_server.js';
export class AudioStreamJobContext {
    sessionId;
    plivoCallUuid;
    streamId;
    direction;
    extraHeaders;
    endpoint;
    userdata;
    room;
    proc;
    job;
    workerId = 'local';
    sessionDirectory;
    inferenceExecutor;
    metadata = {};
    /** Account ID for multi-tenancy — set by the consumer per session. */
    accountId;
    /** @internal Primary AgentSession used by LiveKit job-context helpers. */
    _primaryAgentSession = undefined;
    _session = null;
    _callEnded;
    _resolveCallEnded;
    _shutdownCallbacks = [];
    _shutdownCallbacksFired = false;
    constructor(opts) {
        const agentName = opts.agentName ?? 'audio-stream-agent';
        this.sessionId = opts.sessionId;
        this.plivoCallUuid = opts.plivoCallUuid;
        this.streamId = opts.streamId;
        this.direction = opts.direction;
        this.extraHeaders = opts.extraHeaders;
        this.endpoint = opts.endpoint;
        this.proc = opts.proc ?? new JobProcess();
        this.userdata = opts.userdata;
        this._callEnded = opts.callEnded;
        this._resolveCallEnded = opts.resolveCallEnded;
        this.inferenceExecutor = opts.inferenceExecutor;
        this.sessionDirectory = opts.sessionDirectory ?? '/tmp/agent-sessions';
        try {
            mkdirSync(this.sessionDirectory, { recursive: true });
        }
        catch { }
        this.room = new TransportRoom(opts.endpoint, opts.sessionId, {
            agentName,
            callerIdentity: opts.plivoCallUuid,
        });
        this.job = {
            id: `job-${opts.sessionId}`,
            agentName,
            enableRecording: opts.enableRecording ?? false,
            room: this.room,
        };
    }
    get session() {
        return this._session;
    }
    /**
     * Set the agent session — automatically wires audio stream I/O.
     * After setting, call session.start({ agent, room: ctx.room }).
     */
    set session(session) {
        this._session = session;
        this._primaryAgentSession = session;
        // Wire audio stream I/O (uses same SipAudioInput/Output — they work with AudioStreamEndpoint too)
        session.input.audio = new SipAudioInput(this.endpoint, this.sessionId);
        session.output.audio = new SipAudioOutput(this.endpoint, this.sessionId);
        // Wrap session.start() to disable RoomIO audio replacement (matches SIP JobContext)
        const originalStart = session.start.bind(session);
        session.start = async (opts) => {
            opts = { ...opts };
            opts.inputOptions = { ...opts.inputOptions, audioEnabled: false };
            opts.outputOptions = { ...opts.outputOptions, audioEnabled: false };
            await originalStart(opts);
            // Work around LiveKit SDK bug: StreamAdapter adds anonymous listeners per speech
            try {
                const tts = session.tts;
                if (tts?.setMaxListeners) {
                    tts.setMaxListeners(100);
                    writeSync(2, `[AudioStreamContext] TTS maxListeners set to 100\n`);
                }
            }
            catch { }
        };
        session.on('close', async () => {
            console.log(`Session ${this.sessionId} closed`);
            await this.runShutdownCallbacks('session closed');
            this._resolveCallEnded();
            try {
                this.endpoint.hangup(this.sessionId);
            }
            catch { }
        });
    }
    setMetadata(metadata) {
        for (const [key, value] of Object.entries(metadata)) {
            if (value !== undefined && value !== null) {
                this.metadata[key] = value;
            }
        }
        const accountId = this.metadata.account_id ?? this.metadata.accountId;
        if (accountId !== undefined && accountId !== null) {
            this.accountId = String(accountId);
            this.metadata.account_id = this.accountId;
        }
    }
    addShutdownCallback(callback) {
        this._shutdownCallbacks.push(callback);
    }
    async runShutdownCallbacks(reason) {
        if (this._shutdownCallbacksFired)
            return;
        this._shutdownCallbacksFired = true;
        for (const cb of this._shutdownCallbacks) {
            try {
                await cb(reason);
            }
            catch { }
        }
    }
    /**
     * Terminate the agent job and drop the underlying audio_stream call.
     *
     * Matches the Python `JobContext.shutdown(reason)` contract and
     * mirrors `JobContext.shutdown` in `session_context.ts` (SIP variant).
     * Idempotent — `endpoint.hangup` is a no-op once the session is gone.
     *
     * Behavior:
     *   1. Fires all registered shutdown callbacks (fire-and-forget on
     *      the event loop; exceptions from user callbacks are swallowed).
     *   2. Calls `endpoint.hangup(sessionId)` to drop the Plivo WS session.
     *   3. Resolves the internal `callEnded` promise so the server's
     *      entrypoint runner proceeds to cleanup.
     */
    shutdown(reason = '') {
        console.log(`Session ${this.sessionId} JobContext.shutdown(reason=${JSON.stringify(reason)})`);
        this.runShutdownCallbacks(reason).catch(() => { });
        try {
            this.endpoint.hangup(this.sessionId);
        }
        catch {
            /* session already gone */
        }
        try {
            this._resolveCallEnded();
        }
        catch {
            /* already resolved */
        }
    }
    /**
     * Async equivalent of shutdown — matches Python `JobContext.delete_room`.
     *
     * LiveKit's real `delete_room` returns a Future/Promise; our stub maps
     * it directly to `endpoint.hangup`. Safe to call multiple times; safe
     * to call before or after `shutdown()`. This is the method
     * `EndCallTool` calls via its shutdown callback when `deleteRoom: true`.
     */
    async deleteRoom(_roomName = '') {
        try {
            this.endpoint.hangup(this.sessionId);
        }
        catch {
            /* already gone */
        }
    }
    /** @internal */
    get callEnded() {
        return this._callEnded;
    }
    isFakeJob() {
        return false;
    }
    is_fake_job() {
        return false;
    }
    async connect() {
        // The audio stream transport is already connected by the time the agent starts.
    }
    initRecording() {
        // agent-transport owns mixed transport recording; LiveKit RecorderIO is disabled.
    }
}
