/**
 * LiveKit Agents TypeScript adapters for agent-transport.
 *
 * Implements LiveKit's AudioInput/AudioOutput abstract classes and
 * TransportRoom facade using agent-transport's SipEndpoint or AudioStreamEndpoint.
 *
 * Usage:
 *   import { SipAudioInput, SipAudioOutput, TransportRoom } from 'agent-transport-adapters/livekit';
 *   import { SipEndpoint } from 'agent-transport';
 *
 *   const ep = new SipEndpoint({ sipServer: 'phone.plivo.com' });
 *   const room = new TransportRoom(ep, sessionId, { agentName: 'my-agent', callerIdentity: remoteUri });
 *   const input = new SipAudioInput(ep, sessionId);
 *   const output = new SipAudioOutput(ep, sessionId);
 *
 *   // Connect to LiveKit AgentSession
 *   session.input.audio = input;
 *   session.output.audio = output;
 *   await session.start({ agent: myAgent, room });
 */
import { SipAudioInput } from './sip_audio_input.js';
import { SipAudioOutput } from './sip_audio_output.js';
export interface AudioOutputCapabilities {
    pause: boolean;
}
export interface PlaybackFinishedEvent {
    playbackPosition: number;
    interrupted: boolean;
    synchronizedTranscript?: string;
}
export interface PlaybackStartedEvent {
    createdAt: number;
}
export interface AudioFrame {
    data: Int16Array | Uint8Array;
    sampleRate: number;
    numChannels: number;
    samplesPerChannel: number;
}
export interface SipDTMF {
    code: number;
    digit: string;
    participant?: TransportRemoteParticipant;
}
export interface TransportEndpoint {
    sendAudioBytes(sessionId: string, audio: Uint8Array, sampleRate: number, numChannels: number): void;
    sendBackgroundAudio(sessionId: string, audio: Uint8Array, sampleRate: number, numChannels: number): void;
    sendDtmf(sessionId: string, digits: string): void;
    sendDtmfAsync(sessionId: string, digits: string, method?: string): Promise<void>;
    sendRawMessage(sessionId: string, message: string): void;
    recvAudioBytesBlocking(sessionId: string, timeoutMs?: number): Uint8Array | null;
    recvAudioBytesAsync(sessionId: string, timeoutMs?: number): Promise<Buffer | null>;
    flush(sessionId: string): void;
    clearBuffer(sessionId: string): void;
    pause(sessionId: string): void;
    resume(sessionId: string): void;
    queuedFrames(sessionId: string): number;
    waitForPlayout(sessionId: string, timeoutMs?: number): boolean;
    waitForPlayoutAsync(sessionId: string, timeoutMs?: number): Promise<boolean>;
    sampleRate: number;
}
type EventCallback = (...args: any[]) => void;
export declare class EventEmitter {
    private _events;
    on(event: string, callback: EventCallback): EventCallback;
    off(event: string, callback: EventCallback): void;
    emit(event: string, ...args: any[]): void;
}
export declare class StubTrackPublication {
    sid: string;
    track: any;
    name: string;
    kind: number;
    source: number;
    muted: boolean;
    constructor(track: any, sid?: string);
    waitForSubscription(): Promise<void>;
}
export declare class TransportRemoteParticipant {
    sid: string;
    identity: string;
    name: string;
    metadata: string;
    attributes: Record<string, string>;
    kind: number;
    disconnect_reason: number | null;
    trackPublications: Record<string, any>;
    info: {
        kind: number;
        sid: string;
        identity: string;
        name: string;
        metadata: string;
    };
    constructor(identity: string, sessionId: string);
}
export declare class TransportLocalParticipant {
    private _endpoint;
    private _sessionId;
    private _forwardAborts;
    sid: string;
    identity: string;
    name: string;
    metadata: string;
    attributes: Record<string, string>;
    kind: number;
    trackPublications: Record<string, StubTrackPublication>;
    constructor(endpoint: TransportEndpoint, sessionId: string, agentName: string);
    publishDtmf({ code, digit }: {
        code: number;
        digit: string;
    }): Promise<void>;
    publishTrack(track: any, options?: any): Promise<StubTrackPublication>;
    unpublishTrack(trackSid: string): Promise<void>;
    private _forwardTrackAudio;
    publishTranscription(transcription: any): Promise<void>;
    streamText(opts?: any): Promise<{
        write(text: string): Promise<void>;
        close(): Promise<void>;
        aclose(): Promise<void>;
    }>;
    streamBytes(name: string, opts?: any): Promise<{
        write(data: Uint8Array): Promise<void>;
        close(): Promise<void>;
        aclose(): Promise<void>;
    }>;
    sendText(text: string, opts?: any): Promise<void>;
    publishData(payload: string | Uint8Array, opts?: any): Promise<void>;
    setMetadata(metadata: string): Promise<void>;
    setName(name: string): Promise<void>;
    setAttributes(attributes: Record<string, string>): Promise<void>;
    registerRpcMethod(methodName: string, handler?: any): any;
    unregisterRpcMethod(method: string): void;
    setTrackSubscriptionPermissions(opts: any): void;
    performRpc(opts: any): Promise<string>;
    sendFile(filePath: string, opts?: any): Promise<void>;
}
export declare class TransportRoom extends EventEmitter {
    private _endpoint;
    private _sessionId;
    private _connected;
    private _creationTime;
    private _textStreamHandlers;
    localParticipant: TransportLocalParticipant;
    remoteParticipants: Map<string, TransportRemoteParticipant>;
    private _remote;
    constructor(endpoint: TransportEndpoint, sessionId: string, opts: {
        agentName: string;
        callerIdentity: string;
    });
    get name(): string;
    get sid(): string;
    get metadata(): string;
    get connectionState(): number;
    get numParticipants(): number;
    get numPublishers(): number;
    get isRecording(): boolean;
    get departureTimeout(): number;
    get emptyTimeout(): number;
    get e2eeManager(): null;
    get creationTime(): Date;
    get isConnected(): boolean;
    connect(url?: string, token?: string, options?: any): Promise<void>;
    disconnect(): Promise<void>;
    getRtcStats(): Promise<null>;
    registerTextStreamHandler(topic: string, handler: any): void;
    unregisterTextStreamHandler(topic: string): void;
    registerByteStreamHandler(topic: string, handler: any): void;
    unregisterByteStreamHandler(topic: string): void;
    /** Called when the call/stream ends — emit disconnected event.
     * participant_disconnected is emitted separately by the server event loop
     * when call_terminated arrives (matching LiveKit WebRTC pattern). */
    _onSessionEnded(): void;
    /** Emit participant_disconnected (called by server on call_terminated). */
    emitParticipantDisconnected(): void;
    /** Emit DTMF event (called by server event loop). */
    emitDtmf(digit: string): void;
}
export declare class AudioStreamInput extends SipAudioInput {
    constructor(endpoint: TransportEndpoint, sessionId: string);
}
export declare class AudioStreamOutput extends SipAudioOutput {
    constructor(endpoint: TransportEndpoint, sessionId: string, options?: {
        label?: string;
        capabilities?: AudioOutputCapabilities;
        sampleRate?: number;
        nextInChain?: SipAudioOutput;
    });
}
export {};
