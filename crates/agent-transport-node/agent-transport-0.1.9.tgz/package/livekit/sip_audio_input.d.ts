/**
 * SipAudioInput — extends LiveKit's AudioInput base class for SIP/AudioStream.
 *
 * Architecture matches Python SipAudioInput and LiveKit's _ParticipantAudioInputStream:
 * - Extends AudioInput (from @livekit/agents internal io.js)
 * - A forwarding task reads from Rust and pushes frames into a ReadableStream
 * - That ReadableStream is added to the base class multiStream
 * - On stream end, pushes 0.5s silence to flush STT, then closes
 */
import { AudioFrame } from '@livekit/rtc-node';
import type { ReadableStream as NodeReadableStream } from 'node:stream/web';
import type { SipEndpoint, AudioStreamEndpoint } from 'agent-transport';
declare const _AudioInputBase: any;
export interface SipAudioInput {
    multiStream: {
        addInputStream(source: NodeReadableStream<AudioFrame>): string;
        removeInputStream(id: string): Promise<void>;
    };
}
export declare class SipAudioInput extends _AudioInputBase {
    private endpoint;
    private sessionId;
    private closed;
    private attached;
    private inputStreamId;
    constructor(endpoint: SipEndpoint | AudioStreamEndpoint, sessionId: string);
    /**
     * Start the forwarding task that reads from Rust and pushes to multiStream.
     * Matches Python's start() / _forward_audio pattern.
     */
    start(): void;
    /**
     * Push 0.5s silence to flush STT, then close the stream.
     * Matches Python's _forward_audio finally block.
     */
    private pushSilenceAndClose;
    onAttached(): void;
    onDetached(): void;
    close(): Promise<void>;
}
export {};
