/**
 * AudioStreamServer — Plivo audio streaming equivalent of AgentServer.
 *
 * No SIP credentials needed — Plivo connects to your WebSocket server.
 * Configure Plivo XML to return:
 *   <Response>
 *     <Stream bidirectional="true" keepCallAlive="true"
 *       contentType="audio/x-mulaw;rate=8000">
 *       wss://your-server:8765
 *     </Stream>
 *   </Response>
 *
 * Usage:
 *   const server = new AudioStreamServer({ listenAddr: '0.0.0.0:8765' });
 *   server.audioStreamSession(async (ctx) => {
 *     const session = new voice.AgentSession({ ... });
 *     ctx.session = session;
 *     await session.start({ agent, room: ctx.room });
 *   });
 *   server.run();
 */
import { createServer } from 'node:http';
import { hostname, cpus } from 'node:os';
import { AudioStreamEndpoint } from 'agent-transport';
import { initializeLogger, InferenceRunner, runWithJobContext } from '@livekit/agents';
import { AudioStreamJobContext } from './audio_stream_context.js';
import { JobProcess } from './agent_server.js';
import { uploadReport, getObservabilityUrl } from './observability.js';
class LoadMonitor {
    samples = [];
    windowSize = 5;
    timer;
    constructor() {
        this.timer = setInterval(() => this.sample(), 500);
        this.timer.unref();
    }
    sample() {
        const cpuList = cpus();
        let idle = 0;
        let total = 0;
        for (const cpu of cpuList) {
            idle += cpu.times.idle;
            total += cpu.times.user + cpu.times.nice + cpu.times.sys + cpu.times.irq + cpu.times.idle;
        }
        const usage = 1 - idle / total;
        this.samples.push(usage);
        if (this.samples.length > this.windowSize)
            this.samples.shift();
    }
    getLoad() {
        if (this.samples.length === 0)
            return 0;
        return this.samples.reduce((a, b) => a + b, 0) / this.samples.length;
    }
    stop() {
        clearInterval(this.timer);
    }
}
export class AudioStreamServer {
    listenAddr;
    plivoAuthId;
    plivoAuthToken;
    sampleRate;
    host;
    port;
    agentName;
    authFn;
    entrypointFn;
    setupFn;
    userdata = {};
    proc = new JobProcess();
    ep;
    activeSessions = new Map();
    httpServer;
    loadMonitor = new LoadMonitor();
    inferenceExecutor;
    sessionCount = 0;
    sessionDurations = [];
    // Cooperative shutdown flag for the WS event loop. The loop checks this
    // each iteration and breaks when set, so the run() promise can await the
    // loop's exit before tearing down. Without this, the infinite poll loop
    // would pin Node's libuv event loop forever.
    shutdownRequested = false;
    constructor(opts) {
        this.listenAddr = opts.listenAddr ?? process.env.AUDIO_STREAM_ADDR ?? '0.0.0.0:8765';
        this.plivoAuthId = opts.plivoAuthId ?? process.env.PLIVO_AUTH_ID ?? '';
        this.plivoAuthToken = opts.plivoAuthToken ?? process.env.PLIVO_AUTH_TOKEN ?? '';
        this.sampleRate = opts.sampleRate ?? 8000;
        this.host = opts.host ?? '0.0.0.0';
        this.port = opts.port ?? parseInt(process.env.PORT ?? '8080');
        this.agentName = opts.agentName ?? 'audio-stream-agent';
        this.authFn = opts.auth;
    }
    setup(fn) {
        this.setupFn = fn;
    }
    /**
     * LiveKit-compatible setup_fnc setter — accepts a function that receives a JobProcess.
     */
    set setupFnc(fn) {
        this.setupFn = fn;
    }
    audioStreamSession(fn) {
        this.entrypointFn = fn;
    }
    async run() {
        // Handle unhandled rejections from LiveKit SDK TTS abort paths gracefully
        process.on('unhandledRejection', (reason) => {
            if (reason === undefined || reason === null)
                return;
            console.error('Unhandled rejection:', reason);
        });
        // Strip tsx/ts-node loader hooks from execArgv before any child process forks
        const cleanArgv = [];
        for (let i = 0; i < process.execArgv.length; i++) {
            const arg = process.execArgv[i];
            const next = process.execArgv[i + 1] ?? '';
            if ((arg === '--require' || arg === '--import') && (next.includes('tsx') || next.includes('ts-node'))) {
                i++;
            }
            else {
                cleanArgv.push(arg);
            }
        }
        process.execArgv = cleanArgv;
        const mode = process.argv[2] ?? 'start';
        // Handle download-files command (downloads model files for turn detection etc.)
        if (mode === 'download-files') {
            initializeLogger({ pretty: true, level: 'info' });
            const { Plugin, log: agentLog } = await import('@livekit/agents');
            const logger = agentLog();
            for (const plugin of Plugin.registeredPlugins) {
                logger.info(`Downloading files for ${plugin.title}`);
                await plugin.downloadFiles();
                logger.info(`Finished: ${plugin.title}`);
            }
            process.exit(0);
        }
        if (!this.entrypointFn) {
            console.error('No audio stream session entrypoint registered.\n' +
                'Define one using server.audioStreamSession(async (ctx) => { ... })');
            process.exit(1);
        }
        // Initialize inference executor (for turn detection)
        if (this.setupFn) {
            try {
                initializeLogger({ pretty: true, level: 'info' });
                const runners = InferenceRunner?.registeredRunners;
                if (runners && Object.keys(runners).length > 0) {
                    let InferenceProcExecutor = null;
                    try {
                        const { createRequire } = await import('node:module');
                        const require = createRequire(import.meta.url);
                        const agentsPath = require.resolve('@livekit/agents');
                        const execPath = agentsPath.replace(/dist\/index\.(c?)js$/, 'dist/ipc/inference_proc_executor.$1js');
                        const mod = require(execPath);
                        InferenceProcExecutor = mod?.InferenceProcExecutor ?? null;
                    }
                    catch { /* not available */ }
                    if (InferenceProcExecutor) {
                        this.inferenceExecutor = new InferenceProcExecutor({
                            runners,
                            initializeTimeout: 5 * 60_000,
                            closeTimeout: 5000,
                            memoryWarnMb: 2000,
                            memoryLimitMb: 0,
                            pingInterval: 5000,
                            pingTimeout: 60_000,
                            highPingThreshold: 2500,
                        });
                        await this.inferenceExecutor.start();
                        await this.inferenceExecutor.initialize();
                        console.log('Inference executor ready (turn detection models available)');
                    }
                }
                // Run setup with job context stub for inference executor
                if (this.inferenceExecutor) {
                    const stub = { inferenceExecutor: this.inferenceExecutor };
                    await runWithJobContext(stub, () => this.callSetupFn());
                }
                else {
                    await this.callSetupFn();
                }
            }
            catch (e) {
                console.warn('Setup failed:', e?.message || e);
                await this.callSetupFn();
            }
            console.log(`Setup complete: ${Object.keys(this.userdata).join(', ')}`);
        }
        // Create AudioStreamEndpoint (starts WS server)
        this.ep = new AudioStreamEndpoint({
            listenAddr: this.listenAddr,
            plivoAuthId: this.plivoAuthId,
            plivoAuthToken: this.plivoAuthToken,
            inputSampleRate: this.sampleRate,
            outputSampleRate: this.sampleRate,
        });
        console.log(`Audio stream WebSocket server on ws://${this.listenAddr}`);
        // Start HTTP server
        this.startHttpServer();
        console.log(`HTTP server on http://${this.host}:${this.port}`);
        const obsUrl = getObservabilityUrl();
        if (obsUrl) {
            console.log(`Observability enabled, target ${obsUrl}`);
        }
        // Start event loop. Track the promise so we can await its exit during
        // shutdown — without this the infinite while loop pins libuv forever.
        const eventLoopDone = this.eventLoop();
        // Wait for shutdown signal
        await new Promise((resolve) => {
            const shutdown = async () => {
                console.log('Shutting down...');
                this.shutdownRequested = true;
                // Drain active sessions with 10-second timeout
                if (this.activeSessions.size > 0) {
                    console.log(`Draining ${this.activeSessions.size} active session(s)...`);
                    await Promise.race([
                        Promise.allSettled([...this.activeSessions.values()].map((s) => s.promise)),
                        new Promise((r) => setTimeout(() => {
                            console.warn('Shutdown timeout reached (10s), forcing exit');
                            r();
                        }, 10000)),
                    ]);
                }
                this.loadMonitor.stop();
                if (this.httpServer)
                    this.httpServer.close();
                if (this.ep)
                    this.ep.shutdown();
                // Wait for the event loop to actually exit so Node releases its
                // libuv handle. ep.shutdown() pushes a Shutdown sentinel that wakes
                // the loop immediately.
                await eventLoopDone;
                resolve();
            };
            process.on('SIGINT', shutdown);
            process.on('SIGTERM', shutdown);
        });
    }
    /**
     * Call the setup function, supporting both LiveKit proc pattern and plain pattern.
     */
    async callSetupFn() {
        if (!this.setupFn)
            return;
        const result = await this.setupFn(this.proc);
        if (result && typeof result === 'object' && !(result instanceof Promise)) {
            Object.assign(this.proc.userData, result);
        }
        this.userdata = this.proc.userData;
    }
    // ─── Event loop ─────────────────────────────────────────────────────
    async eventLoop() {
        // With the post-answer event refactor, Plivo's WebSocket `start` maps
        // directly to `call_answered` — the session is created immediately.
        // No pending map, no wait-for-first-media gate.
        while (!this.shutdownRequested) {
            const ev = await this.waitForEvent(1000);
            if (!ev)
                continue;
            // Sentinel pushed by ep.shutdown() — wake immediately and exit cleanly.
            if (ev.eventType === 'shutdown') {
                break;
            }
            if (ev.eventType === 'call_answered' && ev.session) {
                // Plivo WebSocket start → Rust fired CallAnswered → create agent.
                const session = ev.session;
                const sessionId = session.sessionId;
                const plivoCallUuid = session.remoteUri;
                const streamId = session.localUri ?? '';
                const extraHeaders = session.extraHeaders ?? {};
                if (this.activeSessions.has(sessionId)) {
                    // Defensive: duplicate event or retry.
                    continue;
                }
                console.log(`Audio stream session ${sessionId} connected (plivo_call_uuid=${plivoCallUuid}, stream_id=${streamId})`);
                this.startSession(sessionId, plivoCallUuid, streamId, extraHeaders).catch((err) => {
                    console.error(`Session ${sessionId} startup failed:`, err);
                    try {
                        this.ep.hangup(sessionId);
                    }
                    catch { }
                });
            }
            else if (ev.eventType === 'call_terminated' && ev.session) {
                const sessionId = ev.session.sessionId;
                const reason = ev.reason ?? 'unknown';
                console.log(`Session ${sessionId} terminated (reason=${reason})`);
                // Shut down the session gracefully BEFORE emitting
                // participant_disconnected. LiveKit's default handler calls
                // `_closeSoon({ drain: false })`, which force-interrupts any in-flight
                // LLM/TTS response — the final assistant message (e.g. the reply
                // after a tool call) would never land in chat_history. Calling
                // `shutdown({ drain: true })` first sets the closing state so the
                // subsequent `_closeSoon` becomes a no-op and the session drains
                // normally, letting in-flight speech finalize into history.
                const active = this.activeSessions.get(sessionId);
                if (active?.ctx?.session?.shutdown) {
                    try {
                        active.ctx.session.shutdown({ drain: true });
                    }
                    catch (err) {
                        console.warn(`Graceful session shutdown failed for ${sessionId}; falling back to default close`, err);
                    }
                }
                // Emit participant_disconnected on Room facade.
                if (active?.room) {
                    active.room.emitParticipantDisconnected();
                }
                if (active) {
                    active.resolveEnded();
                }
            }
            else if (ev.eventType === 'dtmf_received' && ev.sessionId) {
                const active = this.activeSessions.get(ev.sessionId);
                if (active?.room) {
                    active.room.emitDtmf(ev.digit ?? '');
                }
            }
            else if (ev.eventType === 'beep_detected' && ev.sessionId) {
                const active = this.activeSessions.get(ev.sessionId);
                if (active?.room) {
                    active.room.emit('beep_detected', { frequencyHz: ev.frequencyHz ?? 0, durationMs: ev.durationMs ?? 0 });
                }
            }
            else if (ev.eventType === 'beep_timeout' && ev.sessionId) {
                const active = this.activeSessions.get(ev.sessionId);
                if (active?.room) {
                    active.room.emit('beep_timeout', {});
                }
            }
        }
    }
    async startSession(sessionId, plivoCallUuid, streamId, extraHeaders) {
        let resolveEnded;
        const callEnded = new Promise((r) => { resolveEnded = r; });
        const ctx = new AudioStreamJobContext({
            sessionId,
            plivoCallUuid,
            streamId,
            direction: 'inbound',
            extraHeaders,
            endpoint: this.ep,
            userdata: this.userdata,
            agentName: this.agentName,
            callEnded,
            resolveCallEnded: resolveEnded,
            proc: this.proc,
            inferenceExecutor: this.inferenceExecutor,
            enableRecording: false,
        });
        const runSession = async () => {
            this.sessionCount++;
            const sessionStart = performance.now();
            const sessionDir = ctx.sessionDirectory;
            let recPath;
            let recordingStartedAt;
            try {
                if (runWithJobContext) {
                    await runWithJobContext(ctx, () => this.entrypointFn(ctx));
                }
                else {
                    await this.entrypointFn(ctx);
                }
                // Start Rust recording (stereo OGG/Opus at transport layer)
                try {
                    const { mkdirSync } = await import('node:fs');
                    mkdirSync(sessionDir, { recursive: true });
                    recPath = `${sessionDir}/recording_${sessionId}.ogg`;
                    recordingStartedAt = Date.now();
                    this.ep.startRecording(sessionId, recPath, true);
                    console.log(`Recording started: ${recPath}`);
                }
                catch { }
                // Hook user state changes for debug logging
                if (ctx.session) {
                    const { writeSync } = await import('node:fs');
                    ctx.session.on('user_state_changed', (ev) => {
                        try {
                            writeSync(2, `Session ${sessionId} user: ${ev.oldState} -> ${ev.newState}\n`);
                        }
                        catch { }
                    });
                }
                // Wait for stream to end
                await ctx.callEnded;
            }
            catch (e) {
                console.error(`Session ${sessionId} handler failed:`, e);
            }
            finally {
                const durationSec = (performance.now() - sessionStart) / 1000;
                this.sessionDurations.push(durationSec);
                if (ctx.session) {
                    try {
                        const usage = ctx.session.usage;
                        if (usage) {
                            console.log(`Session ${sessionId} usage:`, JSON.stringify(usage));
                        }
                    }
                    catch { }
                    // Wait for natural session close (preserves in-flight responses in history)
                    try {
                        await new Promise((resolve) => {
                            const timer = setTimeout(resolve, 5000);
                            ctx.session.on('close', () => { clearTimeout(timer); resolve(); });
                        });
                    }
                    catch {
                        try {
                            await ctx.session.close();
                        }
                        catch { }
                    }
                    // Stop recording and wait for file to be finalized
                    try {
                        this.ep.stopRecording(sessionId);
                    }
                    catch { }
                    const { existsSync } = await import('node:fs');
                    if (recPath) {
                        for (let i = 0; i < 20; i++) {
                            if (existsSync(recPath))
                                break;
                            await new Promise(r => setTimeout(r, 100));
                        }
                    }
                    // Upload session report (transcript, audio, metrics)
                    try {
                        await uploadReport({
                            agentName: this.agentName,
                            session: ctx.session,
                            callId: sessionId,
                            accountId: ctx.accountId,
                            metadata: ctx.metadata,
                            direction: ctx.direction,
                            recordingPath: recPath,
                            recordingStartedAt,
                            transport: 'audio_stream',
                        });
                    }
                    catch (e) {
                        console.warn(`Failed to upload session report for session ${sessionId}:`, e);
                    }
                    // Clean up local recording after upload attempt
                    if (getObservabilityUrl() && recPath) {
                        try {
                            const { unlinkSync } = await import('node:fs');
                            unlinkSync(recPath);
                        }
                        catch (e) {
                            console.warn(`Failed to clean up recording ${recPath}:`, e);
                        }
                    }
                }
                try {
                    this.ep.hangup(sessionId);
                }
                catch { }
                ctx.room._onSessionEnded();
                this.activeSessions.delete(sessionId);
                console.log(`Session ${sessionId} ended, duration=${durationSec.toFixed(1)}s`);
            }
        };
        const sessionPromise = runSession();
        this.activeSessions.set(sessionId, { promise: sessionPromise, resolveEnded, room: ctx.room, ctx });
    }
    // ─── HTTP server ────────────────────────────────────────────────────
    startHttpServer() {
        this.httpServer = createServer(async (req, res) => {
            if (this.authFn && req.url !== '/') {
                const ok = await this.authFn(req);
                if (!ok) {
                    res.writeHead(401);
                    res.end('Unauthorized');
                    return;
                }
            }
            if (req.url === '/') {
                res.writeHead(200);
                res.end('OK');
            }
            else if (req.url === '/worker') {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({
                    agent_name: this.agentName,
                    worker_type: 'JT_AUDIO_STREAM',
                    worker_load: this.loadMonitor.getLoad(),
                    active_jobs: this.activeSessions.size,
                    listen_addr: this.listenAddr,
                }));
            }
            else if (req.url === '/metrics') {
                res.writeHead(200, { 'Content-Type': 'text/plain' });
                res.end(this.generateMetrics());
            }
            else {
                res.writeHead(404);
                res.end('Not Found');
            }
        });
        this.httpServer.listen(this.port, this.host);
    }
    generateMetrics() {
        const node = hostname();
        const lines = [];
        lines.push(`# HELP lk_agents_audio_stream_sessions_total Total audio stream sessions`);
        lines.push(`# TYPE lk_agents_audio_stream_sessions_total counter`);
        lines.push(`lk_agents_audio_stream_sessions_total{nodename="${node}"} ${this.sessionCount}`);
        lines.push(`# HELP lk_agents_active_job_count Active sessions`);
        lines.push(`# TYPE lk_agents_active_job_count gauge`);
        lines.push(`lk_agents_active_job_count{nodename="${node}"} ${this.activeSessions.size}`);
        lines.push(`# HELP lk_agents_cpu_load CPU load`);
        lines.push(`# TYPE lk_agents_cpu_load gauge`);
        lines.push(`lk_agents_cpu_load{nodename="${node}"} ${this.loadMonitor.getLoad().toFixed(4)}`);
        return lines.join('\n') + '\n';
    }
    async waitForEvent(timeoutMs) {
        // Use the napi blocking waitForEvent (runs on the napi thread pool, so
        // the JS event loop is not blocked). Wakes immediately when
        // ep.shutdown() pushes the Shutdown sentinel — much faster than the
        // old setTimeout-based polling and no CPU spin between polls.
        if (!this.ep)
            return null;
        return await this.ep.waitForEvent(timeoutMs);
    }
}
