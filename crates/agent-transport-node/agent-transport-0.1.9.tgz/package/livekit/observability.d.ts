/**
 * Observability setup for agent-transport (Node.js).
 *
 * Keep this layer intentionally thin: build a LiveKit SessionReport, attach
 * Agent Transport metadata to the recording header, and ship native-shaped
 * payloads to observability. Parsing/normalization belongs in observability.
 *
 * Set AGENT_OBSERVABILITY_URL plus LIVEKIT_API_KEY / LIVEKIT_API_SECRET to enable.
 */
import { voice } from '@livekit/agents';
type Transport = 'sip' | 'audio_stream';
interface OtlpLogRecord {
    body: string;
    timestampMs: number;
    attributes: Record<string, unknown>;
}
export declare function getObservabilityUrl(): string | undefined;
export declare function buildRoomTags(options: {
    agentName: string;
    accountId?: string;
    metadata?: Record<string, unknown>;
    transport?: Transport;
    direction?: string;
}): Record<string, string>;
export declare function buildOtlpLogRecords(report: voice.SessionReport, agentName: string, roomTags: Record<string, string>): OtlpLogRecord[];
export declare function uploadReport(options: {
    agentName: string;
    session: any;
    callId: string;
    accountId?: string;
    metadata?: Record<string, unknown>;
    direction?: string;
    recordingPath?: string;
    recordingStartedAt?: number;
    transport?: Transport;
}): Promise<void>;
export {};
