/**
 * AgentServer — SIP equivalent of LiveKit's AgentServer.
 *
 * Handles SIP registration, call routing, HTTP server (health/worker/metrics/call),
 * CLI (start/dev/debug), and call lifecycle management.
 *
 * Usage:
 *   const server = new AgentServer({ sipUsername: '...', sipPassword: '...' });
 *
 *   server.sipSession(async (ctx) => {
 *     const session = new voice.AgentSession({ ... });
 *     await ctx.start(session, { agent });
 *   });
 *
 *   server.run();
 */
import { type IncomingMessage } from 'node:http';
import { JobContext } from './session_context.js';
export declare class JobProcess {
    userData: Record<string, unknown>;
}
export interface AgentServerOptions {
    sipServer?: string;
    sipPort?: number;
    sipUsername: string;
    sipPassword: string;
    host?: string;
    port?: number;
    agentName?: string;
    auth?: (req: IncomingMessage) => boolean | Promise<boolean>;
}
type EntrypointFn = (ctx: JobContext) => Promise<void>;
type SetupFn = () => Record<string, unknown>;
export declare class AgentServer {
    private sipServer;
    private sipPort;
    private sipUsername;
    private sipPassword;
    private host;
    private port;
    private agentName;
    private authFn?;
    private entrypointFn?;
    private setupFn?;
    private userdata;
    private proc;
    private ep?;
    private activeCalls;
    private httpServer?;
    private loadMonitor;
    private inferenceExecutor;
    private serverListeners;
    private outboundSessionIds;
    private shutdownRequested;
    private sipCallsTotal;
    private sipCallDurations;
    constructor(opts: AgentServerOptions);
    /**
     * Register setup function — runs once at startup.
     * Returns a dict of shared resources (VAD, turn detector, etc.)
     * available as ctx.userdata in each call.
     */
    setup(fn: SetupFn): void;
    /**
     * LiveKit-compatible setup_fnc setter — accepts a function that receives a JobProcess.
     */
    set setupFnc(fn: (proc: JobProcess) => void | Record<string, unknown> | Promise<void | Record<string, unknown>>);
    /**
     * Register a server-level event listener.
     *
     * Server events fire before a per-call JobContext exists, so they can't
     * be attached to `ctx`. Use these for pre-answer hooks like call
     * screening, logging, and metrics.
     *
     * Available events:
     *   - `"ringing"` — fires on inbound SIP calls immediately after Rust
     *     has sent 180 Ringing. Handler receives a CallSession with
     *     sessionId, remoteUri, callUuid, extraHeaders. Rust auto-answers
     *     right after this event, so the hook is currently observational
     *     only. Return values / thrown errors are ignored.
     *
     * Handlers may be synchronous or async.
     *
     * ```ts
     * server.on('ringing', (session) => {
     *   console.log(`Incoming call from ${session.remoteUri}`);
     * });
     * ```
     */
    on(eventName: string, callback: (...args: any[]) => void | Promise<void>): void;
    private emitServerEvent;
    /**
     * Register the call entrypoint — equivalent of @server.sip_session().
     */
    sipSession(fn: EntrypointFn): void;
    /**
     * Run the server — registers SIP, starts HTTP, handles calls.
     */
    run(): Promise<void>;
    /**
     * Call the setup function, supporting both LiveKit proc pattern and plain pattern.
     */
    private callSetupFn;
    private sipEventLoop;
    private startCall;
    private startHttpServer;
    private generateMetrics;
    private getSdkVersion;
    private waitForEvent;
    private configureLogging;
}
export {};
