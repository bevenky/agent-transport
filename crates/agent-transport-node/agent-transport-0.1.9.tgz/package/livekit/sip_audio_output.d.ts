/**
 * SipAudioOutput — extends LiveKit's AudioOutput base class for SIP/AudioStream.
 *
 * Matches WebRTC's ParticipantAudioOutput exactly:
 * - captureFrame sends to Rust with backpressure (sendAudioNotify callback)
 * - waitForPlayout uses Rust callback (fires when buffer drains to empty)
 * - queuedDuration reads real Rust buffer state
 * - clearBuffer signals interruption
 * - pause/resume controls Rust RTP output directly
 *
 * No timer heuristics — all playout tracking comes from Rust.
 */
import { AudioFrame } from '@livekit/rtc-node';
import type { SipEndpoint, AudioStreamEndpoint } from 'agent-transport';
declare const _AudioOutputBase: any;
export declare class SipAudioOutput extends _AudioOutputBase {
    private endpoint;
    private sessionId;
    private flushTask;
    private interruptedFuture;
    private firstFrameEmitted;
    private pushedDuration;
    private rustPaused;
    constructor(endpoint: SipEndpoint | AudioStreamEndpoint, sessionId: string, sampleRate?: number, nextInChain?: any);
    captureFrame(frame: AudioFrame): Promise<void>;
    flush(): void;
    clearBuffer(): void;
    pause(): void;
    resume(): void;
    private waitForPlayoutTask;
    /** Wait for playout via Rust callback — no timer, no thread pool. */
    private waitForSourcePlayout;
    /** Clear Rust buffer immediately. */
    private clearSourceQueue;
    close(): Promise<void>;
    onAttached(): void;
    onDetached(): void;
}
export {};
