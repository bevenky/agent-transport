/**
 * LiveKit Agents TypeScript adapters for agent-transport.
 *
 * Implements LiveKit's AudioInput/AudioOutput abstract classes and
 * TransportRoom facade using agent-transport's SipEndpoint or AudioStreamEndpoint.
 *
 * Usage:
 *   import { SipAudioInput, SipAudioOutput, TransportRoom } from 'agent-transport-adapters/livekit';
 *   import { SipEndpoint } from 'agent-transport';
 *
 *   const ep = new SipEndpoint({ sipServer: 'phone.plivo.com' });
 *   const room = new TransportRoom(ep, sessionId, { agentName: 'my-agent', callerIdentity: remoteUri });
 *   const input = new SipAudioInput(ep, sessionId);
 *   const output = new SipAudioOutput(ep, sessionId);
 *
 *   // Connect to LiveKit AgentSession
 *   session.input.audio = input;
 *   session.output.audio = output;
 *   await session.start({ agent: myAgent, room });
 */
import { SipAudioInput } from './sip_audio_input.js';
import { SipAudioOutput } from './sip_audio_output.js';
export class EventEmitter {
    _events = new Map();
    on(event, callback) {
        if (!this._events.has(event))
            this._events.set(event, new Set());
        this._events.get(event).add(callback);
        return callback;
    }
    off(event, callback) {
        this._events.get(event)?.delete(callback);
    }
    emit(event, ...args) {
        for (const cb of this._events.get(event) ?? []) {
            try {
                cb(...args);
            }
            catch (e) {
                console.error(`Error in ${event} listener:`, e);
            }
        }
    }
}
// ─── Stub Track Publication ─────────────────────────────────────────────────
let _pubCounter = 0;
export class StubTrackPublication {
    sid;
    track;
    name = '';
    kind = 0; // AUDIO
    source = 1; // MICROPHONE
    muted = false;
    constructor(track, sid) {
        this.track = track;
        this.sid = sid ?? `TR_${(++_pubCounter).toString(36)}`;
    }
    async waitForSubscription() { }
}
// ─── Transport Remote Participant ───────────────────────────────────────────
export class TransportRemoteParticipant {
    sid;
    identity;
    name;
    metadata = '';
    attributes = {};
    kind = 3; // PARTICIPANT_KIND_SIP (top-level for LiveKit's older API)
    disconnect_reason = null;
    trackPublications = {};
    // LiveKit's RoomIO.onParticipantConnected reads `participant.info.kind`
    // (matching @livekit/rtc-node's ParticipantInfo shape). Without this
    // property, the handler throws `TypeError: Cannot read properties of
    // undefined (reading 'kind')` during RoomIO.init, which surfaces as an
    // unhandled rejection when the session closes.
    info;
    constructor(identity, sessionId) {
        this.sid = `PR_${sessionId}`;
        this.identity = identity;
        this.name = identity;
        this.info = {
            kind: this.kind,
            sid: this.sid,
            identity: this.identity,
            name: this.name,
            metadata: this.metadata,
        };
    }
}
// ─── Transport Local Participant ────────────────────────────────────────────
export class TransportLocalParticipant {
    _endpoint;
    _sessionId;
    _forwardAborts = new Map();
    sid;
    identity;
    name;
    metadata = '';
    attributes = {};
    kind = 0; // STANDARD
    trackPublications = {};
    constructor(endpoint, sessionId, agentName) {
        this._endpoint = endpoint;
        this._sessionId = sessionId;
        this.sid = `PA_${sessionId}`;
        this.identity = agentName;
        this.name = agentName;
    }
    async publishDtmf({ code, digit }) {
        // Use the async napi variant — the sync version blocks the Node
        // event loop for ~280 ms per digit (1 start + 10 continue + 3 end
        // RFC 4733 RTP packets × 20 ms ptime). The async variant runs the
        // pacing on a napi worker thread, freeing the main loop to keep
        // processing audio/LLM/TTS frames. `code` is accepted for LiveKit
        // API compatibility but we don't need it — Rust encodes the digit
        // via its own digit→event mapping.
        void code;
        await this._endpoint.sendDtmfAsync(this._sessionId, digit);
    }
    async publishTrack(track, options) {
        const pub = new StubTrackPublication(track);
        this.trackPublications[pub.sid] = pub;
        // For audio tracks, start forwarding to background mixer
        // This matches Python's _forward_track_audio pattern
        if (track && typeof track.sid === 'string') {
            const abort = new AbortController();
            this._forwardAborts.set(pub.sid, abort);
            this._forwardTrackAudio(pub.sid, track, abort.signal).catch(() => { });
        }
        return pub;
    }
    async unpublishTrack(trackSid) {
        delete this.trackPublications[trackSid];
        const abort = this._forwardAborts.get(trackSid);
        if (abort) {
            abort.abort();
            this._forwardAborts.delete(trackSid);
        }
    }
    async _forwardTrackAudio(pubSid, track, signal) {
        // Read frames from published audio track and forward to Rust background mixer.
        // Uses @livekit/rtc-node AudioStream to loopback-read from the LocalAudioTrack.
        try {
            const { AudioStream } = await import('@livekit/rtc-node');
            const sr = this._endpoint.inputSampleRate ?? 8000;
            const stream = new AudioStream(track, sr, 1);
            const reader = stream.getReader();
            while (!signal.aborted) {
                const { value: frame, done } = await reader.read();
                if (done || signal.aborted)
                    break;
                if (frame.samplesPerChannel > 0) {
                    try {
                        this._endpoint.sendBackgroundAudio(this._sessionId, Buffer.from(frame.data.buffer), frame.sampleRate, frame.channels);
                    }
                    catch {
                        break; // Session gone
                    }
                }
            }
        }
        catch (err) {
            // @livekit/rtc-node AudioStream not available — background audio not supported
            console.warn('Background audio forwarding not available:', err);
            while (!signal.aborted) {
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        }
    }
    async publishTranscription(transcription) { }
    async streamText(opts) {
        return { async write() { }, async close() { }, async aclose() { } };
    }
    async streamBytes(name, opts) {
        return { async write() { }, async close() { }, async aclose() { } };
    }
    async sendText(text, opts) { }
    async publishData(payload, opts) {
        if (typeof payload === 'string') {
            try {
                this._endpoint.sendRawMessage(this._sessionId, payload);
            }
            catch { }
        }
    }
    async setMetadata(metadata) { this.metadata = metadata; }
    async setName(name) { this.name = name; }
    async setAttributes(attributes) {
        const oldState = this.attributes['lk.agent.state'];
        Object.assign(this.attributes, attributes);
        // Log agent state transitions (matches Python AgentServer behavior)
        const newState = this.attributes['lk.agent.state'];
        if (newState && newState !== oldState) {
            try {
                const { log } = await import('@livekit/agents');
                log().info(`Call ${this._sessionId} agent: ${oldState ?? 'initializing'} -> ${newState}`);
            }
            catch {
                console.log(`Call ${this._sessionId} agent: ${oldState ?? 'initializing'} -> ${newState}`);
            }
        }
    }
    registerRpcMethod(methodName, handler) { return handler; }
    unregisterRpcMethod(method) { }
    setTrackSubscriptionPermissions(opts) { }
    async performRpc(opts) { return ''; }
    async sendFile(filePath, opts) { }
}
// ─── Transport Room ─────────────────────────────────────────────────────────
export class TransportRoom extends EventEmitter {
    _endpoint;
    _sessionId;
    _connected = true;
    _creationTime = new Date();
    _textStreamHandlers = new Map();
    localParticipant;
    remoteParticipants;
    _remote;
    constructor(endpoint, sessionId, opts) {
        super();
        this._endpoint = endpoint;
        this._sessionId = sessionId;
        this.localParticipant = new TransportLocalParticipant(endpoint, sessionId, opts.agentName);
        this._remote = new TransportRemoteParticipant(opts.callerIdentity, String(sessionId));
        this.remoteParticipants = new Map([[opts.callerIdentity, this._remote]]);
    }
    get name() { return `transport-${this._sessionId}`; }
    get sid() { return this.name; }
    get metadata() { return ''; }
    get connectionState() { return this._connected ? 3 : 5; }
    get numParticipants() { return this.remoteParticipants.size; }
    get numPublishers() { return 0; }
    get isRecording() { return false; }
    get departureTimeout() { return 0; }
    get emptyTimeout() { return 0; }
    get e2eeManager() { return null; }
    get creationTime() { return this._creationTime; }
    get isConnected() { return this._connected; }
    async connect(url = '', token = '', options) {
        // Already connected via transport — no WebRTC connection needed
    }
    async disconnect() {
        this._connected = false;
        this.emit('disconnected');
    }
    async getRtcStats() { return null; }
    registerTextStreamHandler(topic, handler) {
        this._textStreamHandlers.set(topic, handler);
    }
    unregisterTextStreamHandler(topic) {
        this._textStreamHandlers.delete(topic);
    }
    registerByteStreamHandler(topic, handler) { }
    unregisterByteStreamHandler(topic) { }
    /** Called when the call/stream ends — emit disconnected event.
     * participant_disconnected is emitted separately by the server event loop
     * when call_terminated arrives (matching LiveKit WebRTC pattern). */
    _onSessionEnded() {
        this._connected = false;
        this.emit('disconnected');
    }
    /** Emit participant_disconnected (called by server on call_terminated). */
    emitParticipantDisconnected() {
        this._remote.disconnect_reason = 1; // CLIENT_INITIATED
        this.emit('participant_disconnected', this._remote);
    }
    /** Emit DTMF event (called by server event loop). */
    emitDtmf(digit) {
        const ev = {
            code: digit.charCodeAt(0),
            digit,
            participant: this._remote,
        };
        this.emit('sip_dtmf_received', ev);
    }
}
// Aliases for audio streaming
export class AudioStreamInput extends SipAudioInput {
    constructor(endpoint, sessionId) {
        super(endpoint, sessionId);
    }
}
export class AudioStreamOutput extends SipAudioOutput {
    constructor(endpoint, sessionId, options) {
        super(endpoint, sessionId, options?.sampleRate, options?.nextInChain);
    }
}
