/**
 * SipAudioOutput — extends LiveKit's AudioOutput base class for SIP/AudioStream.
 *
 * Matches WebRTC's ParticipantAudioOutput exactly:
 * - captureFrame sends to Rust with backpressure (sendAudioNotify callback)
 * - waitForPlayout uses Rust callback (fires when buffer drains to empty)
 * - queuedDuration reads real Rust buffer state
 * - clearBuffer signals interruption
 * - pause/resume controls Rust RTP output directly
 *
 * No timer heuristics — all playout tracking comes from Rust.
 */
import { createRequire } from 'node:module';
import { Future, Task } from '@livekit/agents';
// AudioOutput is not publicly exported from @livekit/agents — resolve internal path
const _require = createRequire(import.meta.url);
const _agentsPath = _require.resolve('@livekit/agents');
const _ioPath = _agentsPath.replace(/dist\/index\.(c?)js$/, 'dist/voice/io.$1js');
const { AudioOutput: _AudioOutputBase } = _require(_ioPath);
export class SipAudioOutput extends _AudioOutputBase {
    endpoint;
    sessionId;
    flushTask = null;
    interruptedFuture = new Future();
    firstFrameEmitted = false;
    pushedDuration = 0;
    rustPaused = false;
    constructor(endpoint, sessionId, sampleRate, nextInChain) {
        const _sampleRate = sampleRate ?? endpoint.outputSampleRate;
        super(_sampleRate, nextInChain, { pause: true });
        this.endpoint = endpoint;
        this.sessionId = sessionId;
    }
    // -- captureFrame: matches WebRTC's ParticipantAudioOutput.captureFrame --
    async captureFrame(frame) {
        // Segment tracking (WebRTC's super.captureFrame is sync void)
        super.captureFrame(frame);
        // Track pushed duration before the await so a sync caller's
        // pushedDuration accounting matches what the upstream sync
        // super.captureFrame would have done.
        this.pushedDuration += frame.samplesPerChannel / frame.sampleRate;
        // Push to Rust with backpressure — callback fires when buffer has space.
        // Matches WebRTC's `await audioSource.captureFrame(frame)`.
        const frameData = Buffer.from(frame.data.buffer, frame.data.byteOffset, frame.data.byteLength);
        const isFirstFrame = !this.firstFrameEmitted;
        await new Promise((resolve) => {
            try {
                this.endpoint.sendAudioNotify(this.sessionId, frameData, frame.sampleRate, frame.channels, () => resolve());
            }
            catch {
                // Buffer full or session gone — drop frame silently (matches WebRTC
                // behavior where captureFrame returns false on buffer full without
                // throwing).
                resolve();
            }
        });
        // Emit playback-started AFTER the first frame has actually been
        // accepted by Rust (the napi callback fired). Upstream LiveKit fires
        // it after `await audioSource.captureFrame(frame)` returns, so the
        // TTFB metric reflects "first frame queued for playback" rather than
        // "first frame received from TTS". Firing it before the await would
        // overreport TTFB by ~50-100 ms.
        if (isFirstFrame) {
            this.firstFrameEmitted = true;
            this.onPlaybackStarted(Date.now());
        }
    }
    // -- flush: matches WebRTC's ParticipantAudioOutput.flush --
    flush() {
        super.flush();
        if (!this.pushedDuration)
            return;
        if (this.flushTask && !this.flushTask.done) {
            this.flushTask.cancel();
        }
        this.flushTask = Task.from((controller) => this.waitForPlayoutTask(controller));
    }
    // -- clearBuffer: matches WebRTC's ParticipantAudioOutput.clearBuffer --
    clearBuffer() {
        if (!this.pushedDuration)
            return;
        this.interruptedFuture.resolve();
    }
    // -- pause/resume: call Rust endpoint directly for immediate RTP effect --
    pause() {
        super.pause();
        if (!this.rustPaused) {
            // Update the flag AFTER the FFI call succeeds. If endpoint.pause()
            // throws (e.g., session already closed), the flag must stay false
            // so a subsequent pause() retries instead of being short-circuited
            // by the guard — otherwise Rust keeps sending audio while the TS
            // layer thinks it's paused.
            try {
                this.endpoint.pause(this.sessionId);
                this.rustPaused = true;
            }
            catch { /* session gone */ }
        }
    }
    resume() {
        super.resume();
        if (this.rustPaused) {
            try {
                this.endpoint.resume(this.sessionId);
                this.rustPaused = false;
            }
            catch { /* session gone */ }
        }
    }
    // -- waitForPlayoutTask: matches WebRTC's waitForPlayoutTask exactly --
    async waitForPlayoutTask(abortController) {
        const abortFuture = new Future();
        const resolveAbort = () => {
            if (!abortFuture.done)
                abortFuture.resolve(true);
        };
        if (abortController?.signal) {
            abortController.signal.addEventListener('abort', resolveAbort);
        }
        // Wait for Rust playout — callback fires when buffer drains to empty.
        // Pause-aware: won't fire while paused (RTP loop doesn't drain).
        // Matches WebRTC's audioSource.waitForPlayout().
        this.waitForSourcePlayout().finally(() => {
            if (abortController?.signal) {
                abortController.signal.removeEventListener('abort', resolveAbort);
            }
            if (!abortFuture.done)
                abortFuture.resolve(false);
        });
        const interrupted = await Promise.race([
            abortFuture.await,
            this.interruptedFuture.await.then(() => true),
        ]);
        let pushedDuration = this.pushedDuration;
        if (interrupted) {
            // Real Rust buffer state — matches WebRTC's audioSource.queuedDuration.
            // Always exposed by both SipEndpoint and AudioStreamEndpoint via napi.
            const queuedMs = this.endpoint.queuedDurationMs(this.sessionId);
            pushedDuration = Math.max(this.pushedDuration - queuedMs / 1000, 0);
            this.clearSourceQueue();
        }
        this.pushedDuration = 0;
        this.interruptedFuture = new Future();
        this.firstFrameEmitted = false;
        this.onPlaybackFinished({
            playbackPosition: pushedDuration,
            interrupted,
        });
    }
    // -- Source helpers (using Rust APIs, matching WebRTC's audioSource) --
    /** Wait for playout via Rust callback — no timer, no thread pool. */
    waitForSourcePlayout() {
        return new Promise((resolve) => {
            try {
                this.endpoint.waitForPlayoutNotify(this.sessionId, () => resolve());
            }
            catch {
                resolve(); // Session gone
            }
        });
    }
    /** Clear Rust buffer immediately. */
    clearSourceQueue() {
        try {
            this.endpoint.clearBuffer(this.sessionId);
        }
        catch { /* ignore */ }
    }
    // -- lifecycle --
    async close() {
        if (this.flushTask)
            this.flushTask.cancel();
    }
    onAttached() {
        if (this.nextInChain)
            this.nextInChain.onAttached();
    }
    onDetached() {
        if (this.nextInChain)
            this.nextInChain.onDetached();
    }
}
