/**
 * JobContext — equivalent of LiveKit's JobContext for SIP/AudioStream calls.
 *
 * Matches LiveKit's standard pattern exactly:
 *   server.sipSession(async (ctx) => {
 *     const session = new voice.AgentSession({ ... });
 *     ctx.session = session;
 *     await session.start({ agent, room: ctx.room });
 *   });
 *
 * Setting ctx.session automatically wires SIP audio I/O and registers
 * the close handler. Then session.start({ room: ctx.room }) works exactly
 * like LiveKit WebRTC.
 */
import { mkdirSync } from 'node:fs';
import { SipAudioInput } from './sip_audio_input.js';
import { SipAudioOutput } from './sip_audio_output.js';
import { TransportRoom } from './livekit_adapters.js';
import { JobProcess } from './agent_server.js';
export class JobContext {
    sessionId;
    remoteUri;
    direction;
    endpoint;
    userdata;
    room;
    proc;
    job;
    workerId = 'local';
    sessionDirectory;
    inferenceExecutor;
    metadata = {};
    /** Account ID for multi-tenancy — set by the consumer per session. */
    accountId;
    /** @internal Primary AgentSession used by LiveKit job-context helpers. */
    _primaryAgentSession = undefined;
    _session = null;
    _callEnded;
    _resolveCallEnded;
    _shutdownCallbacks = [];
    _shutdownCallbacksFired = false;
    constructor(opts) {
        const agentName = opts.agentName ?? 'sip-agent';
        this.sessionId = opts.sessionId;
        this.remoteUri = opts.remoteUri;
        this.direction = opts.direction;
        this.endpoint = opts.endpoint;
        this.proc = opts.proc ?? new JobProcess();
        this.userdata = opts.userdata;
        this._callEnded = opts.callEnded;
        this._resolveCallEnded = opts.resolveCallEnded;
        this.inferenceExecutor = opts.inferenceExecutor;
        this.sessionDirectory = opts.sessionDirectory ?? '/tmp/agent-sessions';
        try {
            mkdirSync(this.sessionDirectory, { recursive: true });
        }
        catch { }
        // Create Room facade
        this.room = new TransportRoom(opts.endpoint, opts.sessionId, {
            agentName,
            callerIdentity: opts.remoteUri,
        });
        this.job = {
            id: `job-${opts.sessionId}`,
            agentName,
            enableRecording: opts.enableRecording ?? false,
            room: this.room,
        };
    }
    get session() {
        return this._session;
    }
    /**
     * Set the agent session — automatically wires SIP audio I/O.
     *
     * After setting ctx.session, call session.start({ agent, room: ctx.room })
     * directly — matches LiveKit WebRTC pattern exactly.
     */
    set session(session) {
        if (session == null) {
            throw new TypeError("JobContext.session cannot be set to null/undefined. Assign a "
                + "valid voice.AgentSession instance (or use ctx.session to read).");
        }
        this._session = session;
        this._primaryAgentSession = session;
        // Wire SIP audio I/O before session.start() is called
        session.input.audio = new SipAudioInput(this.endpoint, this.sessionId);
        session.output.audio = new SipAudioOutput(this.endpoint, this.sessionId);
        // Wrap session.start() to disable RoomIO audio replacement.
        // The Python SDK does this internally (sets room_options.audio_input = False when
        // input.audio is already set). The TS SDK doesn't — it creates RoomIO with audio
        // enabled and overwrites our I/O. We fix this by injecting the disable options,
        // so the user can call session.start({ agent, room: ctx.room }) normally.
        const originalStart = session.start.bind(session);
        session.start = async (opts) => {
            opts = { ...opts };
            opts.inputOptions = { ...opts.inputOptions, audioEnabled: false };
            opts.outputOptions = { ...opts.outputOptions, audioEnabled: false };
            await originalStart(opts);
            // Work around LiveKit SDK bug: StreamAdapter (tts/stream_adapter.ts) adds anonymous
            // metrics_collected + error listeners to the TTS emitter on every speech generation
            // but never removes them. With preemptive generation, 11+ speech handles exceed the
            // default maxListeners=10, causing ERR_UNHANDLED_ERROR crash on TTS abort.
            // Ref: StreamAdapter constructor at stream_adapter.ts:24-27
            try {
                const tts = session.tts;
                if (tts?.setMaxListeners) {
                    tts.setMaxListeners(100);
                }
            }
            catch {
                /* best-effort */
            }
        };
        // Listen to session close event — handles agent-initiated shutdown
        session.on('close', async () => {
            console.log(`Call ${this.sessionId} session closed`);
            await this.runShutdownCallbacks('session closed');
            this._resolveCallEnded();
            try {
                this.endpoint.hangup(this.sessionId);
            }
            catch { }
        });
    }
    setMetadata(metadata) {
        for (const [key, value] of Object.entries(metadata)) {
            if (value !== undefined && value !== null) {
                this.metadata[key] = value;
            }
        }
        const accountId = this.metadata.account_id ?? this.metadata.accountId;
        if (accountId !== undefined && accountId !== null) {
            this.accountId = String(accountId);
            this.metadata.account_id = this.accountId;
        }
    }
    addShutdownCallback(callback) {
        this._shutdownCallbacks.push(callback);
    }
    async runShutdownCallbacks(reason) {
        if (this._shutdownCallbacksFired)
            return;
        this._shutdownCallbacksFired = true;
        for (const cb of this._shutdownCallbacks) {
            try {
                await cb(reason);
            }
            catch { }
        }
    }
    /**
     * Terminate the agent job and drop the underlying SIP/audio_stream call.
     *
     * Matches the Python `JobContext.shutdown(reason)` contract and the
     * `AgentSession.shutdown()` flow in TS LiveKit Agents. Idempotent — Rust
     * `endpoint.hangup` is a no-op once the session is gone.
     *
     * User-visible behavior:
     *   1. Fires all registered shutdown callbacks (fire-and-forget on the
     *      event loop; exceptions from user callbacks are swallowed).
     *   2. Calls `endpoint.hangup(sessionId)` to drop the SIP call.
     *   3. Resolves the internal `callEnded` promise so the server's
     *      entrypoint runner proceeds to cleanup.
     */
    shutdown(reason = '') {
        console.log(`Call ${this.sessionId} JobContext.shutdown(reason=${JSON.stringify(reason)})`);
        // Fire user callbacks — fire-and-forget (shutdown() is sync for
        // API parity with LiveKit's JobContext).
        this.runShutdownCallbacks(reason).catch(() => { });
        try {
            this.endpoint.hangup(this.sessionId);
        }
        catch {
            /* session already gone */
        }
        try {
            this._resolveCallEnded();
        }
        catch {
            /* already resolved */
        }
    }
    /**
     * Async equivalent of shutdown — matches Python `JobContext.delete_room`.
     *
     * LiveKit's real `delete_room` returns a Future/Promise; our stub maps
     * it directly to `endpoint.hangup`. Safe to call multiple times; safe
     * to call before or after `shutdown()`.
     */
    async deleteRoom(_roomName = '') {
        try {
            this.endpoint.hangup(this.sessionId);
        }
        catch {
            /* already gone */
        }
    }
    /** @internal Wait for call to end — called by server after entrypoint returns */
    get callEnded() {
        return this._callEnded;
    }
    isFakeJob() {
        return false;
    }
    is_fake_job() {
        return false;
    }
    async connect() {
        // The SIP transport is already connected by the time the agent starts.
    }
    initRecording() {
        // agent-transport owns mixed transport recording; LiveKit RecorderIO is disabled.
    }
}
