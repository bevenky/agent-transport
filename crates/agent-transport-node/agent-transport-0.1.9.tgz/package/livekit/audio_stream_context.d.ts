/**
 * AudioStreamJobContext — equivalent of LiveKit's JobContext for Plivo audio streaming.
 *
 * Matches the SIP JobContext pattern:
 *   server.audioStreamSession(async (ctx) => {
 *     const session = new voice.AgentSession({ ... });
 *     ctx.session = session;
 *     await session.start({ agent, room: ctx.room });
 *   });
 */
import type { AudioStreamEndpoint } from 'agent-transport';
import { TransportRoom } from './livekit_adapters.js';
import { JobProcess } from './agent_server.js';
export interface AudioStreamJobContextOptions {
    sessionId: string;
    plivoCallUuid: string;
    streamId: string;
    direction: 'inbound';
    extraHeaders: Record<string, string>;
    endpoint: AudioStreamEndpoint;
    userdata: Record<string, unknown>;
    agentName?: string;
    callEnded: Promise<void>;
    resolveCallEnded: () => void;
    proc?: JobProcess;
    inferenceExecutor?: unknown;
    enableRecording?: boolean;
    sessionDirectory?: string;
}
export declare class AudioStreamJobContext {
    readonly sessionId: string;
    readonly plivoCallUuid: string;
    readonly streamId: string;
    readonly direction: 'inbound';
    readonly extraHeaders: Record<string, string>;
    readonly endpoint: AudioStreamEndpoint;
    readonly userdata: Record<string, unknown>;
    readonly room: TransportRoom;
    readonly proc: JobProcess;
    readonly job: {
        id: string;
        agentName: string;
        enableRecording: boolean;
        room: TransportRoom;
    };
    readonly workerId = "local";
    readonly sessionDirectory: string;
    readonly inferenceExecutor: unknown;
    metadata: Record<string, unknown>;
    /** Account ID for multi-tenancy — set by the consumer per session. */
    accountId: string | undefined;
    /** @internal Primary AgentSession used by LiveKit job-context helpers. */
    _primaryAgentSession: any;
    private _session;
    private _callEnded;
    private _resolveCallEnded;
    private _shutdownCallbacks;
    private _shutdownCallbacksFired;
    constructor(opts: AudioStreamJobContextOptions);
    get session(): any;
    /**
     * Set the agent session — automatically wires audio stream I/O.
     * After setting, call session.start({ agent, room: ctx.room }).
     */
    set session(session: any);
    setMetadata(metadata: Record<string, unknown>): void;
    addShutdownCallback(callback: (reason?: string) => void | Promise<void>): void;
    private runShutdownCallbacks;
    /**
     * Terminate the agent job and drop the underlying audio_stream call.
     *
     * Matches the Python `JobContext.shutdown(reason)` contract and
     * mirrors `JobContext.shutdown` in `session_context.ts` (SIP variant).
     * Idempotent — `endpoint.hangup` is a no-op once the session is gone.
     *
     * Behavior:
     *   1. Fires all registered shutdown callbacks (fire-and-forget on
     *      the event loop; exceptions from user callbacks are swallowed).
     *   2. Calls `endpoint.hangup(sessionId)` to drop the Plivo WS session.
     *   3. Resolves the internal `callEnded` promise so the server's
     *      entrypoint runner proceeds to cleanup.
     */
    shutdown(reason?: string): void;
    /**
     * Async equivalent of shutdown — matches Python `JobContext.delete_room`.
     *
     * LiveKit's real `delete_room` returns a Future/Promise; our stub maps
     * it directly to `endpoint.hangup`. Safe to call multiple times; safe
     * to call before or after `shutdown()`. This is the method
     * `EndCallTool` calls via its shutdown callback when `deleteRoom: true`.
     */
    deleteRoom(_roomName?: string): Promise<void>;
    /** @internal */
    get callEnded(): Promise<void>;
    isFakeJob(): boolean;
    is_fake_job(): boolean;
    connect(): Promise<void>;
    initRecording(): void;
}
