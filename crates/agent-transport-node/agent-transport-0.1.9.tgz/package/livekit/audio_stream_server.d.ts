/**
 * AudioStreamServer — Plivo audio streaming equivalent of AgentServer.
 *
 * No SIP credentials needed — Plivo connects to your WebSocket server.
 * Configure Plivo XML to return:
 *   <Response>
 *     <Stream bidirectional="true" keepCallAlive="true"
 *       contentType="audio/x-mulaw;rate=8000">
 *       wss://your-server:8765
 *     </Stream>
 *   </Response>
 *
 * Usage:
 *   const server = new AudioStreamServer({ listenAddr: '0.0.0.0:8765' });
 *   server.audioStreamSession(async (ctx) => {
 *     const session = new voice.AgentSession({ ... });
 *     ctx.session = session;
 *     await session.start({ agent, room: ctx.room });
 *   });
 *   server.run();
 */
import { type IncomingMessage } from 'node:http';
import { AudioStreamJobContext } from './audio_stream_context.js';
import { JobProcess } from './agent_server.js';
export interface AudioStreamServerOptions {
    listenAddr?: string;
    plivoAuthId?: string;
    plivoAuthToken?: string;
    sampleRate?: number;
    host?: string;
    port?: number;
    agentName?: string;
    auth?: (req: IncomingMessage) => boolean | Promise<boolean>;
}
type EntrypointFn = (ctx: AudioStreamJobContext) => Promise<void>;
type SetupFn = () => Record<string, unknown>;
export declare class AudioStreamServer {
    private listenAddr;
    private plivoAuthId;
    private plivoAuthToken;
    private sampleRate;
    private host;
    private port;
    private agentName;
    private authFn?;
    private entrypointFn?;
    private setupFn?;
    private userdata;
    private proc;
    private ep?;
    private activeSessions;
    private httpServer?;
    private loadMonitor;
    private inferenceExecutor;
    private sessionCount;
    private sessionDurations;
    private shutdownRequested;
    constructor(opts: AudioStreamServerOptions);
    setup(fn: SetupFn): void;
    /**
     * LiveKit-compatible setup_fnc setter — accepts a function that receives a JobProcess.
     */
    set setupFnc(fn: (proc: JobProcess) => void | Record<string, unknown> | Promise<void | Record<string, unknown>>);
    audioStreamSession(fn: EntrypointFn): void;
    run(): Promise<void>;
    /**
     * Call the setup function, supporting both LiveKit proc pattern and plain pattern.
     */
    private callSetupFn;
    private eventLoop;
    private startSession;
    private startHttpServer;
    private generateMetrics;
    private waitForEvent;
}
export {};
