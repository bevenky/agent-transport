/**
 * JobContext — equivalent of LiveKit's JobContext for SIP/AudioStream calls.
 *
 * Matches LiveKit's standard pattern exactly:
 *   server.sipSession(async (ctx) => {
 *     const session = new voice.AgentSession({ ... });
 *     ctx.session = session;
 *     await session.start({ agent, room: ctx.room });
 *   });
 *
 * Setting ctx.session automatically wires SIP audio I/O and registers
 * the close handler. Then session.start({ room: ctx.room }) works exactly
 * like LiveKit WebRTC.
 */
import type { SipEndpoint } from 'agent-transport';
import { TransportRoom } from './livekit_adapters.js';
import { JobProcess } from './agent_server.js';
export interface JobContextOptions {
    sessionId: string;
    remoteUri: string;
    direction: 'inbound' | 'outbound';
    endpoint: SipEndpoint;
    userdata: Record<string, unknown>;
    agentName?: string;
    callEnded: Promise<void>;
    resolveCallEnded: () => void;
    proc?: JobProcess;
    inferenceExecutor?: unknown;
    enableRecording?: boolean;
    sessionDirectory?: string;
}
export declare class JobContext {
    readonly sessionId: string;
    readonly remoteUri: string;
    readonly direction: 'inbound' | 'outbound';
    readonly endpoint: SipEndpoint;
    readonly userdata: Record<string, unknown>;
    readonly room: TransportRoom;
    readonly proc: JobProcess;
    readonly job: {
        id: string;
        agentName: string;
        enableRecording: boolean;
        room: TransportRoom;
    };
    readonly workerId = "local";
    readonly sessionDirectory: string;
    readonly inferenceExecutor: unknown;
    metadata: Record<string, unknown>;
    /** Account ID for multi-tenancy — set by the consumer per session. */
    accountId: string | undefined;
    /** @internal Primary AgentSession used by LiveKit job-context helpers. */
    _primaryAgentSession: any;
    private _session;
    private _callEnded;
    private _resolveCallEnded;
    private _shutdownCallbacks;
    private _shutdownCallbacksFired;
    constructor(opts: JobContextOptions);
    get session(): any;
    /**
     * Set the agent session — automatically wires SIP audio I/O.
     *
     * After setting ctx.session, call session.start({ agent, room: ctx.room })
     * directly — matches LiveKit WebRTC pattern exactly.
     */
    set session(session: any);
    setMetadata(metadata: Record<string, unknown>): void;
    addShutdownCallback(callback: (reason?: string) => void | Promise<void>): void;
    private runShutdownCallbacks;
    /**
     * Terminate the agent job and drop the underlying SIP/audio_stream call.
     *
     * Matches the Python `JobContext.shutdown(reason)` contract and the
     * `AgentSession.shutdown()` flow in TS LiveKit Agents. Idempotent — Rust
     * `endpoint.hangup` is a no-op once the session is gone.
     *
     * User-visible behavior:
     *   1. Fires all registered shutdown callbacks (fire-and-forget on the
     *      event loop; exceptions from user callbacks are swallowed).
     *   2. Calls `endpoint.hangup(sessionId)` to drop the SIP call.
     *   3. Resolves the internal `callEnded` promise so the server's
     *      entrypoint runner proceeds to cleanup.
     */
    shutdown(reason?: string): void;
    /**
     * Async equivalent of shutdown — matches Python `JobContext.delete_room`.
     *
     * LiveKit's real `delete_room` returns a Future/Promise; our stub maps
     * it directly to `endpoint.hangup`. Safe to call multiple times; safe
     * to call before or after `shutdown()`.
     */
    deleteRoom(_roomName?: string): Promise<void>;
    /** @internal Wait for call to end — called by server after entrypoint returns */
    get callEnded(): Promise<void>;
    isFakeJob(): boolean;
    is_fake_job(): boolean;
    connect(): Promise<void>;
    initRecording(): void;
}
